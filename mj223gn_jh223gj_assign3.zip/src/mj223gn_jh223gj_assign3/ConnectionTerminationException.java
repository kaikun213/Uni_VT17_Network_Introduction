package mj223gn_jh223gj_assign3;

public class ConnectionTerminationException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConnectionTerminationException(){
		super();
	}

}
